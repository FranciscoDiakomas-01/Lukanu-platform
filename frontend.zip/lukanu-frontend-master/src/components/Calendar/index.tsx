"use client";

import * as React from "react";

import { Calendar } from "@/components/ui/calendar";

export default function CalendarApp() {
  const [date, setDate] = React.useState<Date | undefined>(new Date());

  return (
    <Calendar
      mode="single"
      selected={date}
      onSelect={setDate}
      className="rounded-md w-full  border shadow-sm lg:w-[40%] overflow-hidden "
      captionLayout="dropdown"
    />
  );
}
