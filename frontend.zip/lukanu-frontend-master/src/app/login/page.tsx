"use client";
import logo from "@/assets/logo.png";
import { LoginForm } from "@/components/login-form";
import Image from "next/image";

export default function LoginPage() {
  return (
    <div className=" bg-[#000a10] flex min-h-svh flex-col items-center justify-center gap-6 p-6 md:p-10">
      <div className="flex w-full max-w-sm flex-col gap-6">
        <a href="#" className="flex items-center gap-2 self-center font-medium">
          <div className="flex size-6 items-center justify-center rounded-md">
            <Image src={logo} alt="logo" />
          </div>
        </a>
        <LoginForm />
      </div>
    </div>
  );
}
